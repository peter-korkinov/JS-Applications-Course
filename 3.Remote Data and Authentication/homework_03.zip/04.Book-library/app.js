const url = 'http://localhost:3030/jsonstore/collections/books';

const loadButton = document.getElementById('loadBooks');
loadButton.addEventListener('click', loadBooks);

const tableContent = document.querySelector('tbody');
tableContent.innerHTML = '';

const form = document.querySelector('form');
const submitBtn = document.querySelector('form button');
submitBtn.addEventListener('click', postBook);

async function loadBooks() {
  tableContent.innerHTML = '';

  const res = await fetch(url);
  const data  = await res.json();

  for (const i in data) {
    tableContent.appendChild(createRowElement(data[i]));
  }
}

async function postBook(event) {
  event.preventDefault();

  const input = createRecord();

  if (!input) {
    return alert('Invalid input');
  }

  const options = {
    method: 'post',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(input)
  }

  try {
    const res = await fetch(url, options);

    if (res.status != 200) {
      throw new Error(res.statusText);
    }
  } catch (err) {
    alert(err);
  }

  form.reset();
}

async function editBook() {

}

async function deleteBook() {

}

function createRowElement(element) {
  const row = document.createElement('tr');

  const title = document.createElement('td');
  title.textContent = element.title;

  const author = document.createElement('td');
  author.textContent = element.author;

  const editBtn = document.createElement('button');
  editBtn.textContent = 'Edit';
  editBtn.addEventListener('click', editBook);

  const deleteBtn = document.createElement('button');
  deleteBtn.textContent = 'Delete';
  deleteBtn.addEventListener('click', deleteBook);

  const action = document.createElement('td');
  action.appendChild(editBtn);
  action.appendChild(deleteBtn);

  row.appendChild(title);
  row.appendChild(author);
  row.appendChild(action);;

  return row;
}

function createRecord() {
  const data = new FormData(form);

  const title = data.get('title').trim()
  const author = data.get('author').trim()


  if (inputValidator(title, author)) {
    return {
      title: title,
      author: author
    }
  }
}

function inputValidator(title, author) {
  return title && author;
}